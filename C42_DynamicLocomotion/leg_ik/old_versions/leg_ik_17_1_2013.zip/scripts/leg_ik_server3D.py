#!/usr/bin/env python

#####################################################################################
####    creates the leg_ik_server node which computes the IK of the foot in 3D     ##
####    the service handles LegIk.srv sevices                                      ##
####    request is foot coordinates (x,y,z) with reference to the hip              ##
####    resposes are hip (mhx,lhy,uhz) and knee (kny) angles                       ##
#####################################################################################

import roslib; 
roslib.load_manifest('leg_ik')
import ZMP

from ZMP.msg import *
from leg_ik.srv import *
from leg_ik.msg import *
import rospy, math

def swing_leg_ik(req):

    #print "Returning leg joint angles"

    l1=round(0.37700,6) #u_leg
    l2=round(0.42200,6) #l_leg
    eps = 0.00000001

    swing_x = req.pos.Swing_x
    swing_y = req.pos.Swing_y
    swing_z = req.pos.Swing_z  -l1 -l2+ 0.02
    res = LegIkResponse()

    if round((swing_x**2+swing_y**2+swing_z**2),5)<=round((l1+l2)**2,5):

        L1=swing_x**2+swing_y**2+swing_z**2
        L=round(L1,5)
        res.ang.kny = math.acos(round((L-l1**2-l2**2),3)/round((2*l1*l2),3))
        #alph = math.atan2(x,-z)
        #beth = math.acos((l1**2 + L - l2**2)/(2*l1*math.sqrt(L)))
        ztilda = swing_z*math.cos(res.ang.mhx) - swing_y*math.sin(res.ang.mhx)
        cosinus = round(- (l1*ztilda+l2*math.cos(res.ang.kny)*ztilda+swing_x*l2*math.sin(res.ang.kny))/(swing_x**2+ztilda**2),3)
        sinus = round((-swing_x*l1-swing_x*l2*math.cos(res.ang.kny)+ztilda*l2*math.sin(res.ang.kny))/(swing_x**2+ztilda**2),3)
        res.ang.lhy = math.atan2(sinus,cosinus) 
        res.ang.uhz = 0.0
        res.ang.mhx = math.atan2(-swing_y,swing_z) - math.pi
        res.ang.lax = 0#-res.ang.lhy/4
        res.ang.uay = - ( res.ang.kny + res.ang.lhy)

       # rospy.loginfo([res.ang.lhy,res.ang.mhx]) 

    else:

        rospy.loginfo("out of reach") 

    #    rospy.loginfo("swing_x,swing_y,swing_z") 
   #     rospy.loginfo([swing_x,swing_y,swing_z]) 


    return res

def stance_leg_ik(req):

    #print "Returning leg joint angles"

    l1=round(0.37700,6) #u_leg
    l2=round(0.42200,6) #l_leg
    eps = 0.00000001

    hip_x = req.pos.COMx
    hip_y = req.pos.COMy
    hip_z = req.pos.COMz + l1 + l2 - 0.02


    L1=hip_x**2+hip_y**2+hip_z**2
    L=round(L1,6)

    res = LegIkResponse()
    if round((hip_x**2+hip_y**2+hip_z**2),3)<=round((l1+l2)**2,3):
        res.ang.lax = math.atan2(hip_y,hip_z)
        res.ang.kny = math.acos(round((L-l1**2-l2**2),3)/round((2*l1*l2),3))
        ztilda = hip_z*math.cos(res.ang.lax) + hip_y*math.sin(res.ang.lax)

        cosinus = round((-l1*math.sin(res.ang.kny)*hip_x+ztilda*l2+l1*ztilda*math.cos(res.ang.kny))/L,3)
        sinus = round( -(l2*hip_x+l1*math.cos(res.ang.kny)*hip_x+ztilda*l1*math.sin(res.ang.kny))/L,3)

        res.ang.uay = math.atan2(sinus,cosinus)

        th4 = res.ang.kny
        th5 = res.ang.uay
        th6 = res.ang.lax

        res.ang.mhx = -math.atan2(math.sin(th6),math.cos(th4+ th5)*math.cos(th6)) 
        res.ang.lhy = -math.atan2(math.sin(th4 + th5)*math.cos(th6),math.sqrt(( math.cos(th4 + th5) )**2+( math.sin(th4+th5)*math.sin(th6) )**2))
        res.ang.uhz = 0 #need to change

        res.ang.mby =  -res.ang.lhy/7
        res.ang.ubx =  1*res.ang.lax
    else:

        rospy.loginfo("out of reach") 
     
   # rospy.loginfo("lax,kny,uay") 
   # rospy.loginfo([res.ang.lax,res.ang.kny,res.ang.uay]) 
 
    return res



def leg_ik_server():
    rospy.init_node('leg_ik_server')
    s = rospy.Service('swing_leg_ik', LegIk, swing_leg_ik)
    s2 = rospy.Service('stance_leg_ik', LegIk, stance_leg_ik)
    
    rospy.loginfo("Leg ik server ready") 
    rospy.spin()

if __name__ == "__main__":
    leg_ik_server()
